# Security Specification: Apex Ridge Rally Firestore Rules

## 1. Data Invariants
1. **Owner-Isolated Career & Run Data**: Every document in `drivers/{driverId}` and `stageRecords/{recordId}` belongs strictly to one authenticated, email-verified user (`request.auth.uid`). No cross-user reads, blanket `list` scraping, or unauthenticated writes are allowed.
2. **Strict Schema & Key Whitelisting**: Both `create` and `update` enforce exact required/allowed key sets (`hasAll` + `hasOnly` on create; `affectedKeys().hasOnly(...)` + `isValid*` on update) so shadow/ghost fields are rejected.
3. **Immutable Ownership & Creation Timestamps**: `uid` / `ownerUid` and `createdAt` cannot be modified after creation; `createdAt` and `updatedAt` must equal `request.time`.
4. **Bounded Sizes & Numeric Ranges**: Document IDs match `^[a-zA-Z0-9_-]+$` (`<= 128` chars), `driverName` is `1..40` chars, `mode` is `'race'` or `'time_trial'`, `totalLaps` is `2` or `3`, `position` is `1..3`, `totalTimeMs` is `1000..3600000`, `bestLapMs` is `1000..1800000`, and `topSpeedKmh` is `1..400`.
5. **No PII Stored**: Only public-safe `driverName` and numeric race telemetry are persisted.

## 2. The "Dirty Dozen" Attack Payloads (All Must Return `PERMISSION_DENIED`)
1. Unauthenticated read/write to `drivers/user1` or `stageRecords/rec1`.
2. Unverified email (`email_verified: false`) writing to `drivers/{uid}` or `stageRecords/{id}`.
3. Identity spoofing: `drivers/victimUid` created by `attackerUid` with `uid: "victimUid"`.
4. Owner spoofing in `stageRecords`: `ownerUid: "victimUid"` written by `attackerUid`.
5. Cross-user `get` or blanket `list` on `stageRecords` without `resource.data.ownerUid == request.auth.uid`.
6. Shadow/ghost field injection (`isAdmin: true` or `verified: true`) on `drivers` or `stageRecords`.
7. Client-forged timestamp (`createdAt` != `request.time` or `updatedAt` != `request.time`).
8. Mutating immutable `createdAt` or `ownerUid` during `update`.
9. Oversized `driverName` (`> 40` chars) or malformed document ID (`../etc/passwd`, `> 128` chars).
10. Invalid `mode` (`"arcade"`) or out-of-range `totalLaps` (`99`) / `position` (`0`).
11. Negative or absurd `bestLapMs` (`-5` or `99999999`) or `topSpeedKmh` (`9999`).
12. Deleting another user's `stageRecords` document or updating `racesCompleted` downward.
